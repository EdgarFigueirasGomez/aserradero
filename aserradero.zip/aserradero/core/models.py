from django.db import models
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.core.exceptions import ValidationError


class Porcentaje(models.Model):
    nombre = models.CharField(blank=True, null=True, max_length=100)
    madera = models.FloatField()  # Porcentaje destinado a madera
    serrin = models.FloatField()  # Porcentaje destinado a serrín
    lena = models.FloatField()  # Porcentaje destinado a leña

    def __str__(self):
        return f"{self.nombre} - Madera: {self.madera}%, Serrín: {self.serrin}%, Leña: {self.lena}%"


class Lote(models.Model):
    numero_orden = models.AutoField(primary_key=True, verbose_name="Número de orden (incremental)")  # Incremental y único
    nombre = models.CharField(max_length=100)
    fecha = models.DateField()
    diligencia = models.CharField(max_length=100)
    toneladas_totales = models.FloatField()
    porcentaje = models.ForeignKey(Porcentaje, on_delete=models.CASCADE)
    madera_inicial = models.FloatField(
        blank=True,
        null=True,
        verbose_name="Cantidad inicial de madera (Auto)"
    )
    serrin_inicial = models.FloatField(
        blank=True,
        null=True,
        verbose_name="Cantidad inicial de serrín (Auto)"
    )
    lena_inicial = models.FloatField(
        blank=True,
        null=True,
        verbose_name="Cantidad inicial de leña (Auto)"
    )
    madera_restante = models.FloatField(
        default=0,
        verbose_name="Cantidad restante de madera (Auto)"
    )
    serrin_restante = models.FloatField(
        default=0,
        verbose_name="Cantidad restante de serrín (Auto)"
    )
    lena_restante = models.FloatField(
        default=0,
        verbose_name="Cantidad restante de leña (Auto)"
    )

    def reiniciar(self):
        """
        Reinicia los valores de madera_restante, serrin_restante y lena_restante.
        Verifica que el lote no esté vinculado a ninguna venta.
        """
        if self.ventas.exists():
            raise ValidationError(f"El lote {self.nombre} está asociado a una o más ventas y no se puede reiniciar.")

        # Reiniciar los valores restantes al inicial
        self.madera_restante = self.madera_inicial
        self.serrin_restante = self.serrin_inicial
        self.lena_restante = self.lena_inicial

        # Guardar los cambios
        self.save()
        return f"Lote {self.nombre} reiniciado correctamente."


    def save(self, *args, **kwargs):
        # Solo calcular valores iniciales la primera vez (al crear el objeto)
        if not self.pk:  # Si el lote no tiene un ID, significa que es nuevo
            if self.toneladas_totales and self.porcentaje:
                self.madera_inicial = self.toneladas_totales * (self.porcentaje.madera / 100)
                self.serrin_inicial = self.toneladas_totales * (self.porcentaje.serrin / 100)
                self.lena_inicial = self.toneladas_totales * (self.porcentaje.lena / 100)
                # Inicializa los valores restantes como iguales a los iniciales
                self.madera_restante = self.madera_inicial
                self.serrin_restante = self.serrin_inicial
                self.lena_restante = self.lena_inicial

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Lote {self.numero_orden} - {self.nombre}"


class Cliente(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=100)
    numero_de_contacto = models.CharField(max_length=15)

    def __str__(self):
        return self.nombre


class Venta(models.Model):
    codigo_venta = models.AutoField(primary_key=True)
    fecha = models.DateField()
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    madera = models.FloatField(default=0)  # Madera vendida en metros
    serrin = models.FloatField(default=0)  # Serrín vendido en toneladas
    lena = models.FloatField(default=0)  # Leña vendida en toneladas
    lotes = models.ManyToManyField(Lote, through='LoteVenta', related_name='ventas')

    def __str__(self):
        return f"Venta {self.codigo_venta} - Cliente: {self.cliente}"


@receiver(post_save, sender=Venta)
def procesar_venta_despues_de_guardar(sender, instance, created, **kwargs):
    if created:
        # Solo procesa la venta si es una nueva (no al actualizar una existente)
        procesar_venta(instance)

@receiver(pre_delete, sender=Venta)
def devolver_recursos_al_borrar_venta(sender, instance, **kwargs):
    # Obtenemos todas las relaciones LoteVenta asociadas a esta venta
    print(instance)
    print(LoteVenta.objects.filter())
    lote_ventas = LoteVenta.objects.filter(venta=instance)

    print(lote_ventas)

    for lote_venta in lote_ventas:
        lote = lote_venta.lote

        print(f"Procesando Lote: {lote.nombre}")

        # Verificamos y devolvemos los materiales al lote original
        if lote_venta.madera_producida > 0:
            print(f"Devolviendo {lote_venta.madera_producida} madera al lote {lote.nombre}")
            lote.madera_restante += lote_venta.madera_producida
        if lote_venta.serrin_producido > 0:
            print(f"Devolviendo {lote_venta.serrin_producido} serrín al lote {lote.nombre}")
            lote.serrin_restante += lote_venta.serrin_producido
        if lote_venta.lena_producida > 0:
            print(f"Devolviendo {lote_venta.lena_producida} leña al lote {lote.nombre}")
            lote.lena_restante += lote_venta.lena_producida

        # Guardamos los cambios en el lote
        lote.save()
        print(f"Lote actualizado: {lote}")

    # Eliminamos los registros de LoteVenta relacionados con la venta
    lote_ventas.delete()
    print("Registros intermedios eliminados.")

class LoteVenta(models.Model):
    codigo = models.AutoField(primary_key=True)
    lote = models.ForeignKey(Lote, on_delete=models.CASCADE)
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE)
    madera_producida = models.FloatField(default=0, verbose_name="Madera vendida")
    serrin_producido = models.FloatField(default=0, verbose_name="Serrín vendido")
    lena_producida = models.FloatField(default=0, verbose_name="Leña vendida")

    def __str__(self):
        return f"LoteVenta {self.codigo} - Lote: {self.lote.numero_orden} - Venta: {self.venta.codigo_venta}"


def procesar_venta(venta):
    madera_restante = venta.madera
    serrin_restante = venta.serrin
    lena_restante = venta.lena

    # Obtenemos los lotes disponibles en orden de prelación
    lotes = Lote.objects.filter(
        models.Q(madera_restante__gt=0) |
        models.Q(serrin_restante__gt=0) |
        models.Q(lena_restante__gt=0)
    ).order_by("numero_orden")

    for lote in lotes:
        # Si no queda nada más por procesar, salimos del bucle
        if madera_restante <= 0 and serrin_restante <= 0 and lena_restante <= 0:
            break

        # Reducir madera
        madera_a_usar = min(madera_restante, lote.madera_restante)
        lote.madera_restante -= madera_a_usar
        madera_restante -= madera_a_usar

        # Reducir serrín
        serrin_a_usar = min(serrin_restante, lote.serrin_restante)
        lote.serrin_restante -= serrin_a_usar
        serrin_restante -= serrin_a_usar

        # Reducir leña
        lena_a_usar = min(lena_restante, lote.lena_restante)
        lote.lena_restante -= lena_a_usar
        lena_restante -= lena_a_usar

        # Guardar los cambios en el lote
        lote.save()

        # Crear un registro en la tabla intermedia
        if madera_a_usar > 0 or serrin_a_usar > 0 or lena_a_usar > 0:
            LoteVenta.objects.create(
                lote=lote,
                venta=venta,
                madera_producida=madera_a_usar,
                serrin_producido=serrin_a_usar,
                lena_producida=lena_a_usar,
            )

    # Verificamos si no se pudieron satisfacer los requisitos de la venta
    if madera_restante > 0 or serrin_restante > 0 or lena_restante > 0:
        raise ValueError("No hay suficientes recursos en los lotes para completar esta venta.")