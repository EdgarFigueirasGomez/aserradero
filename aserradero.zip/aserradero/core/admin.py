from django.contrib import admin
from core.models import *
from django.contrib import messages
from core.filters import LoteFilter  # Importamos el filtro desde el nuevo archivo


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ('codigo', 'nombre', 'numero_de_contacto')

class LoteVentaInline(admin.TabularInline):
    model = LoteVenta
    extra = 0  # No mostrar filas adicionales vacías
    readonly_fields = ('lote', 'madera_producida', 'serrin_producido', 'lena_producida')

@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ('codigo_venta', 'fecha', 'cliente', 'madera', 'serrin', 'lena')
    list_filter = ('cliente', LoteFilter)
    inlines = [LoteVentaInline]
    date_hierarchy = 'fecha'  # Jerarquía basada en la fecha de la venta

@admin.register(Lote)
class LoteAdmin(admin.ModelAdmin):
    list_display = ('nombre' ,'numero_orden', 'madera_restante', 'serrin_restante', 'lena_restante', 'toneladas_totales',)
    readonly_fields = ('madera_inicial', 'serrin_inicial', 'lena_inicial', 'madera_restante', 'serrin_restante', 'lena_restante')
    list_filter = ('fecha',)
    date_hierarchy = 'fecha'  # Jerarquía basada en la fecha de la venta
    actions = ['reiniciar_lotes']

    @admin.action(description='Reiniciar lotes seleccionados')
    def reiniciar_lotes(self, request, queryset):
        for lote in queryset:
            try:
                # Llamar a la función reiniciar_lote para cada lote seleccionado
                mensaje = lote.reiniciar()
                self.message_user(request, mensaje, messages.SUCCESS)
            except ValidationError as e:
                self.message_user(request, f"No se pudo reiniciar el lote {lote.nombre}: {e}", messages.ERROR)



@admin.register(Porcentaje)
class PorcentajeAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'madera', 'serrin', 'lena')

@admin.register(LoteVenta)
class LoteVentaAdmin(admin.ModelAdmin):
    list_display = ('codigo', 'lote', 'venta', 'madera_producida', 'serrin_producido', 'lena_producida')
    search_fields = ('codigo', 'lote__nombre', 'venta__codigo_venta')
    list_filter = ('lote','venta')


@admin.register(StockTotal)
class StockTotalAdmin(admin.ModelAdmin):
    date_hierarchy = 'fecha'  # Jerarquía basada en la fecha de la venta
    list_display = ("fecha", "madera_total", "serrin_total", "lena_total", "toneladas_totales")
    list_filter = ("fecha",)
    search_fields = ("fecha",)
    ordering = ("-fecha",)

    def toneladas_totales(self, obj):
        return obj.toneladas_totales  # Usamos la propiedad en la vista de admin

    toneladas_totales.short_description = "Toneladas Totales"

@admin.register(StockActual)
class StockActualAdmin(admin.ModelAdmin):
    """Admin para manejar el stock actual."""
    list_display = ("fecha", "madera_total", "serrin_total", "lena_total", "toneladas_totales")

    def has_add_permission(self, request):
        """Impide agregar nuevos registros."""
        return False

    def has_delete_permission(self, request, obj=None):
        """Impide eliminar el registro."""
        return False