from django.contrib.admin import SimpleListFilter
from core.models import Lote

class LoteFilter(SimpleListFilter):
    """
    Filtro personalizado para buscar ventas según los lotes asociados.
    """
    title = "Lote"
    parameter_name = "lote"

    def lookups(self, request, model_admin):
        """
        Devuelve una lista de opciones para filtrar.
        """
        lotes = Lote.objects.all()
        return [(lote.numero_orden, lote.nombre) for lote in lotes]

    def queryset(self, request, queryset):
        """
        Filtra el queryset según el lote seleccionado.
        """
        if self.value():
            return queryset.filter(lotes__numero_orden=self.value())
        return queryset
