from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from .models import StockTotal

@staff_member_required  # Restringe el acceso a usuarios del admin
def stock_actual_view(request):
    """ Vista dentro del admin para mostrar el Stock Actual """
    stock_actual = StockTotal.objects.order_by('-fecha').first()  # Obtiene el último registro
    return render(request, 'admin/stock_actual_admin.html', {'stock': stock_actual})
